=== MasterStudy Application Package ===

MasterStudy Application Package includes two .ZIP files: WordPress API Plugin & Flutter Application Package.


== Table of Contents ==

## masterstudy-lms-learning-management-system-api.zip

MasterStudy LMS Learning Management System API - API plugin for MasterStudy Learning Management System.

You need to install MasterStudy LMS API Plugin.
From the admin panel of your website go to "Plugins > Add New > Upload Plugins".
Upload the zip plugin file and install it.

## masterstudyapplication-release-*.zip

Flutter Application Package for working on Android Studio or Xcode.


== Documentation ==

Here you can find detailed documentation - https://docs.stylemixthemes.com/masterstudy-app-documentatioin/.
